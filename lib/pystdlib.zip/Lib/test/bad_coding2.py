﻿#coding: uft8
print '我'

#Changed for Jython because the original "coding: utf8" is supposed to be a 
#misspelling, but Java accepts this spelling for an encoding.
